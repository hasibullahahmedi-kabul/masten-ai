# Masten AI — Final Production Source

یک دستیار فارسی Android با هسته Offline-first، Voice، TTS، اجرای سرویس بعد از Boot، Notification Listener، Media/App actions، تماس از طریق Dialer، حافظه SQLite و Backend اختیاری Ollama/FastAPI.

## Android
در Android Studio ریشه پروژه را باز کن و Run/Build APK بگیر.

اگر فعلاً کامپیوتر نداری، در docs/BUILD_ON_PHONE_FA.md راهنمای ساخت APK فقط با گوشی (از طریق GitHub Actions یا Termux) آمده.

مجوزهای حساس را خود Android از کاربر می‌خواهد. برای خواندن اعلان‌ها باید از Settings > Notification access، دسترسی Masten را فعال کنی.

## AI محلی
در یک سیستم دارای Ollama:

```bash
ollama pull llama3
cd backend
./run.sh
```

برای گوشی می‌توانی Backend را روی کامپیوتر داخل شبکه اجرا کنی و آدرس آن را در کلاینت قرار دهی.

## قابلیت‌های عملی
- Voice فارسی و TTS
- اجرای سرویس Foreground
- شروع سرویس بعد از Boot
- اعلام صوتی اعلان‌های سیستم پس از فعال‌کردن Notification Access
- بازکردن برنامه‌های نصب‌شده پشتیبانی‌شده
- بازکردن Dialer برای تماس
- بازکردن Media Player برای ویدیو
- حافظه SQLite در Backend
- تولید پاسخ با Ollama
- تحلیل فایل‌های متنی/کد/CSV در Backend
- Intent routing
- تأیید عملیات حساس در Backend
- ارسال پیامک با متن آماده (تأیید نهایی با کاربر)
- اشتراک‌گذاری/ارسال پیام به واتساپ، تلگرام، ایمیل و... از طریق منوی اشتراک‌گذاری اندروید (تأیید نهایی با کاربر)
- ترجمه چندزبانه روی خود دستگاه (ML Kit)، تشخیص خودکار زبان مبدا
- دوبله فیلم/سریال با Backend (STT + ترجمه آفلاین + TTS + جایگزینی صدا) — نصب و راهنما در docs/DUBBING_FA.md

## محدودیت‌های پلتفرم
ارسال خودکار یا کنترل داخلی WhatsApp/Instagram/Facebook بدون API/مجوز رسمی قابل تضمین نیست. Masten از Android intents و مسیرهای مجاز استفاده می‌کند؛ برای Connector رسمی هر سرویس باید credentials و API همان سرویس فراهم شود.

این پروژه منبع کامل است، اما APK از قبل کامپایل‌شده نیست چون build نهایی باید با SDK/Android Studio محیط مقصد انجام و روی دستگاه واقعی تست شود.
